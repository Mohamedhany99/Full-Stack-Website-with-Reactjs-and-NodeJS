import axios from "axios";
import { useEffect, useState } from "react";
const NewForm = () => {
    const [name, setName] = useState('')
    const [age, setAge] = useState('')
    const [address, setAddress] = useState('')
    const [usersarr, setusersarr] = useState([])
    useEffect(() => {
        showuser()
      },[]);
    const send = () =>{
        
        axios({
            method: 'post',
            data:{name:name,age:age,address:address},
            headers:{
                'Accept': 'application/json, text/plain, */*',
                'Content-Type': 'application/json'
            },
            url: "http://localhost:8080/api/tutorials/adduser"
        }).then((resp) => {
            showuser()
            console.log("Then ",resp)
        }).catch((resp) => {
            console.log("Error ", resp)
        })
    }
    const deleteuser = (userid) =>{
        
        axios({
            method: 'delete',
      
            headers:{
                'Accept': 'application/json, text/plain, */*',
                'Content-Type': 'application/json'
            },
            url: "http://localhost:8080/api/tutorials/deleteuser/"+userid
        }).then((resp) => {
            showuser()
            console.log("Then ",resp)
        }).catch((resp) => {
            console.log("Error ", resp)
        })
    }
    const updateuser = (userid,newname) =>{
        
        axios({
            method: 'put',
            data:{name:newname},
            headers:{
                'Accept': 'application/json, text/plain, */*',
                'Content-Type': 'application/json'
            },
            url: "http://localhost:8080/api/tutorials/updateuser/"+userid
        }).then((resp) => {
            showuser()
            console.log("Then ",resp)
        }).catch((resp) => {
            console.log("Error ", resp)
        })
    }
    const showuser = () =>{
        
        axios({
            method: 'get',
         
            headers:{
                'Accept': 'application/json, text/plain, */*',
                'Content-Type': 'application/json'
            },
            url: "http://localhost:8080/api/tutorials/showusers"
        }).then((resp) => {
            console.log("Then ",resp)
       
            setusersarr(resp.data)
        }).catch((resp) => {
            console.log("Error ", resp)
        })
    }
    return (
        <div className="formcontainer">
            <label className="formheader">Enter your data for Email notifications!</label>
            <label className="formcontent">Enter your name:
                <input onChange={(e)=>setName(e.target.value)} name="name" type='text'/>
            </label>
            <label  className="formcontent">Enter your Age:
                <input onChange={(e)=>setAge(e.target.value)} name="age" Style="align-self:flex-end;" type='numeric'/>
            </label>
            <label className="formcontent">Enter your address:
                <input onChange={(e) => setAddress(e.target.value)} name="add" type='text'/>
            </label>
            <button onClick={()=>send()}>send</button>

            <h1>{usersarr.length}Users:</h1>
            <div style={{width:'200px',height:'100px'}}>
            {usersarr.map(function(item,index){
            return(
                <div style={{backgroundColor:'#000',color:'#fff',border:'1px solid black', borderRadius:'15px',marginBottom:'10px'}}>
                <strong><p style={{fontFamily:'Quicksand',fontSize:'20',marginLeft:'20%'}}>Name:{'  '}{item.name}</p></strong>
                <p style={{fontFamily:'Quicksand'}}>Age:{item.age}</p>
                <p style={{fontFamily:'Quicksand'}}>Address:{item.address}</p>
            <div style={{display:'flex',flexDirection:'row',flex:1}}>
                <button style={{backgroundColor:'red',flex:1,borderRadius:'10px',alignSelf:'center'}}
                    onClick={()=>{
                    deleteuser(item.id)
                }}
                >Delete</button>
                <button style={{backgroundColor:'green',flex:1, borderRadius:'10px',alignSelf:'flex-end'}}
                onClick={()=>{
                    var newname = window.prompt('Enter The User New Name:')
                    updateuser(item.id,newname)
                }}
                >update</button>
            </div>
    </div>
)

            })}
            </div>
        </div>
      );
}
 
export default NewForm;