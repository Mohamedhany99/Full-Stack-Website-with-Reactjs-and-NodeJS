const Home = () => {
    const handlclick =  ()=>{
        console.log("hello hany");
    }
    const handleclicknew = (name) =>{
        console.log("hello    "+name);
    }
    return (
        <div className="home">
            <h2>Homepage</h2>
            <button onClick={handlclick}>Click</button>
            <button onClick={() => handleclicknew("hany")}>Click new</button>
        </div>
      );
}
 
export default Home;