import logo from './logo.svg';
import Navbar from './Navbar';
import Home from './Home';
import React from 'react';
import NewForm from './newform';
import axios from 'axios';
class App extends React.Component 
{
  // constructor(props)
  // {
  //   super(props);
  //   this.state={apiResponse:""};
  // }
  // callAPI()
  // {
  //   fetch("http://localhost:9000/testapi").then(res=>res.text).then(res=>this.setState({apiResponse:res}));


  // }

  // }
  // componentWillMount()
  // {
  //   this.callAPI();
  // }
  // const SubmitData = ()=> {
  //   const options={
  //     method:'GET',
  //     url:'http://localhost:5000/results',
  //     params:{name: Name , age: Age ,add:Add},
  //   }

  render() {
    return (
  <div className="App">

      <Navbar/>
      {/* <p>{this.state.apiResponse}</p> */}
      <div className="content">
        <Home/>
      </div>
      <div>
        <NewForm/>
      </div>
  </div>
  );
}
}
export default App;
