const PORT = 5000
var express = require('express')
// var router = express.Router();
const cors = require('cors');
require('dotenv').config()
const axios = require('axios');
const app = express()

/* GET home page. */
app.get('/',(req,res)=>{
    res.json('hi')
})
app.post('/results',(req,res)=>{
    res.json('hi you are in the results')
     const passedLevel = req.query.level
    res.json(passedLevel)
    console.log(passedLevel)
    // const options = {
    //     method: 'POST',
    //     url: 'https://twinword-word-association-quiz.p.rapidapi.com/type1/',
    //     params:{name: "" , age: "" ,address:""},
    //     headers: {
    //         'Access-Control-Allow-Origin': '*',
    //         "Access-Control-Allow-Methods": "*",
    //         "Access-Control-Allow-Headers": "Origin, X-Requested-With, Content-Type, Accept",
    //         'x-rapidapi-host': 'twinword-word-association-quiz.p.rapidapi.com',
    //         'x-rapidapi-key': process.env.REACT_APP_RAPID_API_KEY
    //     }
    // }

    // axios.request(options).then((response) => {
    //     res.json(response.data)

    // }).catch((error) => {
    //     console.error(error)
    // })
})


app.listen(PORT,()=>console.log('server running on Port 5000'))
