module.exports = app => {
  const tutorials = require("../controllers/tutorial.controller.js");

  var router = require("express").Router();

  // Create a new Tutorial
  router.post("/adduser", tutorials.create);

  // Retrieve all Tutorials
  router.get("/showusers", tutorials.findAll);

  // Update a Tutorial with id
  router.put("/updateuser/:id", tutorials.update);

  // Delete a Tutorial with id
  router.delete("/deleteuser/:id", tutorials.delete);

  app.use('/api/tutorials', router);
};
